// font11x16.h

#ifndef _FONT11X16_h
#define _FONT11X16_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include "fontStruct.h"

extern const fontStruct font11x16;

#endif

